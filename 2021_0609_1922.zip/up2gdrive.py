#!/usr/bin/env python3

import os
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive
import time
import linuxZipit as linzip
from datetime import datetime
import shutil
import traceback

gauth = GoogleAuth()
drive = GoogleDrive(gauth)

filename = linzip.final_file

source_dir = "/home/User/backup/scripts/linuxScripts/"
backup_dir = "/home/User/backup/temp/"

def G_Upload(backup_dir):
	os.chdir(backup_dir)
	upload_file_list = filename
	gfile = drive.CreateFile({'parents': [{'id': '1c7B_jNPLD2yGvimQz699sNf1A72j9_Ug'}]})
	gfile.SetContentFile(upload_file_list)
	gfile.Upload()
	time.sleep(1)

linzip.Archiving(source_dir,backup_dir)
time.sleep(1)
G_Upload(backup_dir)
print('Done')
time.sleep(1)
