#!/usr/bin/env python3

import subprocess
import os
from datetime import datetime
import shutil
import time
import linuxZipit as linzip

cmd = 'git'
remote = 'minecraft'
branch = 'main'
filename = linzip.final_file
source_dir = "/home/User/backup/scripts/linuxScripts/"
backup_dir = "/home/User/backup/repo/"

def gitupdate(source_dir, backup_dir,filename):
	update = subprocess.Popen([cmd, 'fetch', remote, branch])
	pullup = subprocess.Popen([cmd, 'pull', remote, branch])
	linzip.Archiving(source_dir, backup_dir)
	time.sleep(1)
	add2push(backup_dir,filename)

def add2push(filename, backup_dir):
	os.system(cmd+' add '+filename)
	message = 'backed up test folder as .zip file'
	commit = subprocess.Popen([cmd, 'commit',  '-m', message])
	time.sleep(1)
	os.system(cmd+' push '+' '+remote+' '+branch)
	print('Done')
	time.sleep(1)

gitupdate(source_dir, backup_dir, filename)
