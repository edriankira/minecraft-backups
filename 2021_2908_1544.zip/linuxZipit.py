#!/usr/bin/env python3

import os
from datetime import datetime
import shutil
import traceback

now = datetime.now()
archive_name = now.strftime("%Y_%d%m_%H%M")
final_file = archive_name + '.zip'

def Archiving(source_dir, backup_dir):
	try:
		os.chdir(backup_dir)
		shutil.make_archive(archive_name, 'zip', source_dir)

	except:
		traceback.print_exc()
		print("Something went wrong while archiving")